
public class Traversal {

	static final Ocean ocean = new Ocean(0);
	static final int pathColor = 200;
	static final int deadEndColor = 100;
	
	static void slow(){
		try {
			Thread.sleep(10);
		} catch (InterruptedException e) {}
	}
	

    ///////////// Metodos a serem completados ///////////// 
	
		
	static void q21() {
	}

	static void q22() {
	}

	// convenções de marca: 1 (WEST), 2(SOUTH), 3(EAST), 4(NORTH)
	static final int WEST = 1, SOUTH = 2, EAST = 3, NORTH = 4;

	static void q23() {
	}


	static void backTrack() {
	}
	

	public static void main(String[] args) {
	    q1();
	}

}	